Algoritmo ejercicio5
	Escribir "===EJERCICIO #5==="
	Definir m Como Real
	Escribir "Escriba el mes que desee saber 1-12" Sin Saltar
	Leer m
	
	Segun m Hacer
		1:
			Escribir "Enero - 31 d�as"
		2:
			Escribir "Febrero - 28 d�as"
		3:
			Escribir "Marzo - 31 d�as"
		4:
			Escribir "Abril - 30 d�as"
		5:
			Escribir "Mayo - 31 d�as"
		6:
			Escribir "Junio - 30 d�as"
		7:
			Escribir "Julio - 31 d�as"
		8:
			Escribir "Agosto - 31 d�as"
		9:
			Escribir "Septiembre - 30 d�as"
		10:
			Escribir "Octubre - 31 d�as"
		11:
			Escribir "Noviembre - 31 d�as"
		12:
			Escribir "Diciembre - 31 d�as"
		De Otro Modo:
			Escribir "Digite un numero en el rango"
	Fin Segun
FinAlgoritmo
